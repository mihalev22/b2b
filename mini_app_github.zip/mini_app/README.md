# Номенклатура — автономный mini_app

Python/FastAPI + HTML/CSS/JS: загрузка PDF/DOCX/TXT/CSV/XLSX → отдельные позиции через Ollama → совместимые query-эмбеддинги → пять **различных кодов** в существующей большой PostgreSQL **`ktru.public.ktru`**.

**На GitHub достаточно загрузить содержимое этой папки.** Соседние проекты больше не нужны: необходимые ранее работающие readers/vision/embedding-модули включены в [vendor](<vendor/>). Их алгоритмы сохранены, исправлены только относительные импорты. База PostgreSQL и модели Ollama не входят в репозиторий.

## Состав

```text
mini_app/                    # корень отдельного репозитория; название clone-папки может быть любым
  pyproject.toml             # установка пакета + команда ktru-mini
  requirements.txt           # закреплённые проверенные зависимости
  .env.example, .gitignore    # без паролей
  __init__.py, launch.py      # пакет и локальный запуск
  app.py                     # FastAPI /jobs и страница
  config.py, jobs.py          # настройки и ограниченная очередь
  extraction.py              # проверяемое извлечение
  embedding.py, catalog.py    # совместимые query-векторы и read-only PostgreSQL
  vendor/                    # необходимые парсеры/vision/embedding
  static/                    # HTML/CSS/JavaScript
  tests/                     # unit/HTTP регрессии
  sample_dataset/             # примеры пяти форматов + ожидаемая разметка
```

В соседнюю `mini_app_support/` вынесены **не нужные для запуска и публикации**: прежнее виртуальное окружение, локальные загрузки/состояния, диагностические скрипты, JSON-отчёты, скриншоты и кеши. Не загружайте её на GitHub. Создаваемые новым запуском `.venv`, `local_data`, `*.egg-info` и build-products игнорируются Git.

## Запуск после клонирования — без Docker и без DSH

Нужен **Python 3.12**, доступ к существующей PostgreSQL и Ollama **на backend-сервере**. Браузеру модели/GPU не требуются. Команды PowerShell выполняйте **внутри клонированной папки**, где находится [pyproject.toml](<pyproject.toml>):

```PowerShell
python -m venv .venv
& .venv/Scripts/python.exe -m pip install --upgrade pip
& .venv/Scripts/python.exe -m pip install -e .

$env:PGHOST = '127.0.0.1'       # либо согласованный адрес существующего каталога
$env:PGPORT = '5432'
$env:PGDATABASE = 'ktru'
$env:PGUSER = 'ai_agent'
$env:OLLAMA_URL = 'http://127.0.0.1:11434'
$secure = Read-Host 'Пароль PostgreSQL ai_agent' -AsSecureString
$env:PGPASSWORD = [System.Net.NetworkCredential]::new('', $secure).Password

# Если сервис Ollama ещё не запущен: ollama serve в отдельной консоли.
# Если моделей нет, скачивать только на backend:
# ollama pull embeddinggemma:300m
# ollama pull qwen3.5:2b-q4_K_M

& .venv/Scripts/python.exe -m mini_app.launch
# Или после активации окружения: ktru-mini
# После остановки процесса: Remove-Item Env:PGPASSWORD
```

**URL: http://127.0.0.1:8008/**. Один процесс, localhost, один тяжёлый worker. Порт: `--port 8009`. Установка `pip install -e .` позволяет запускать из clone-папки с любым названием; Python-пакет называется `mini_app`. На Linux/macOS используйте `.venv/bin/python` и соответствующий синтаксис environment.

Альтернатива с установленным uv:

```PowerShell
uv venv --python 3.12 .venv
uv pip install --python .venv/Scripts/python.exe -e .
& .venv/Scripts/python.exe -m mini_app.launch
```

Пароль можно задавать через внешний `PGPASSFILE` с ограниченными правами ОС. [Пример настроек](<.env.example>) — без секретов, **не загружается автоматически**. Доступ команды к удалённой PostgreSQL согласует администратор; приложение само не меняет права, сеть или схему базы.

### Необязательный запуск владельца через профиль vector-db

```PowerShell
& .venv/Scripts/python.exe -m mini_app.launch --from-vector-db
```

Только этот флаг требует `DSH_PROFILE_DIR` и существующий MCP-профиль `vector-db`. URI читается в память без вывода/сохранения пароля. Остальным участникам DSH/MCP для runtime **не требуются**: достаточно libpq-переменных.

## Проверочный датасет

[Описание](<sample_dataset/README.md>) и [ожидаемые данные](<sample_dataset/expected.json>). Пять основных форматов содержат **по 8 позиций**, в том числе три одинаковые строки сравнения между форматами. Дополнительно: настоящий растровый PDF, пустой файл, безопасное неподдерживаемое расширение, injection-only и смешанный документ.

Разметка содержит количество/порядок позиций, name, явные brand/model, технические требования, quantity/unit, источники и дубликаты. **Это не готовые результаты приложения и не заранее подобранные коды КТРУ.** Выдача зависит от каталога/режима; корректность кода для закупки проверяется отдельно.

Порядок проверки: один файл → сравнить позиции с разметкой → несколько файлов вместе → vector/hybrid → all-history/latest ACTIVE. Для каждой позиции проверить пять разных кодов и характеристики. Закупочное количество не должно менять семантическое описание одинакового товара. Негативные примеры отправляйте вместе с валидным: его успех не должен скрываться.

```PowerShell
# Unit/HTTP регрессии; не проверка качества модели:
& .venv/Scripts/python.exe -m unittest discover -s tests -v
# Генератор не перезаписывает исходный набор, создаёт новую папку:
& .venv/Scripts/python.exe sample_dataset/generate_dataset.py --help
& .venv/Scripts/python.exe sample_dataset/generate_dataset.py --output C:/Temp/ktru_new_dataset
```

Для регенерации PDF задайте `DATASET_FONT` на доступный кириллический TTF, если отсутствует Windows Arial. Готовые документы уже содержат нужные данные и не требуют модели для открытия. Проверки структуры DOCX/XLSX и извлечения текста PDF выполнены; успешное извлечение нейросетью **всего** набора не предполагается автоматически.

## API и интеграция команды

```text
POST /jobs                 multipart: files[], ranking=vector|hybrid, latest_active=true|false
                           202 {job_id,status}; затем обработка в worker
GET /jobs                  список локальных заданий
GET /jobs/{id}             этап, файл, прогресс, timings, errors
GET /jobs/{id}/results      items[], source/raw_text/attributes/quantity/candidates[], отдельные errors[]
GET /health                модели и проверенные метаданные каталога
```

Другая frontend-часть команды может использовать этот контракт через согласованный same-origin proxy. В Python доступна `mini_app.app.create_app()`; manager/worker создаются в lifespan. При встраивании в другой FastAPI необходимо явно управлять lifespan дочернего приложения: простое `mount` не инициализирует worker. HTML использует пути от корня; prefix-монтирование требует адаптации static/API-путей. Не подключайте старые prepare/save/index-функции к этой части.

## Ранжирование и совместимость

* Источник только `public.ktru`, база `ktru`, пользователь `ai_agent`; запрещён тестовый порт 55432. Нет SQLite, JSON-каталога, `ktru_vector`, `ktru_candidates`, новых таблиц или пересчёта каталога.
* SQL параметризован и read-only. Каждый поиск сверяет идентичность/число записей в REPEATABLE READ / READ ONLY снимке. Вложенные архивные XML/JSON исключены из проекции атрибутов.
* **По векторам:** точный `embedding <=> query_vector`, меньший distance лучше. HNSW не используется: scoring MATERIALIZED, index/bitmap scan отключены до ранжирования. `cosine_similarity = 1 - cosine_distance`, не вероятность кода.
* По всей истории вычисляется ближайшая запись каждого code, затем пять кодов. При равенстве distance: численно большая version, snapshot SHA DESC, record ID DESC. Название не меняет векторный порядок.
* **Latest ACTIVE:** сначала численно последняя версия каждого кода с тем же разрешением равенства, затем ACTIVE. Нечисловые версии блокируют проверку; нет тихого выбора «последней когда-то ACTIVE» версии.
* **Hybrid:** 50 ближайших различных кодов; `name_score = 0.5*Jaccard(tokens) + 0.5*SequenceMatcher`. Нормализация регистра/пробелов/ё→е; числа, маркировки, отрицания сохранены. Без подогнанных товарных словарей.
* `vector_score = clamp((cosine_similarity+1)/2,0,1)`; `combined_score = 0.8*vector_score + 0.2*name_score`. Веса/pool настраиваются; сумма весов =1. Не оптимальные обученные веса. Hybrid не выдаётся за косинусную ближайшую пятёрку.
* `embeddinggemma:300m`, fingerprint/768/algorithm проверяются по каталогу. Query format `task: search result | query: `; document format `title: none | text: `. Batch до 8, `truncate=false`, конечность/размерность/ненулевая норма. Никаких случайных/нулевых/TF-IDF/hash-векторов.
* Query: name, явные brand/model и technical attributes; не raw_text, source/IDs/имена файлов и не quantity/unit закупки. Технические ядра/порты сохраняются.

## Извлечение, очередь, безопасность

Цитаты текстового источника проверяются с whitespace-normalization; brand/model/числа/единицы сверяются с источником/заголовком. Простые значения/диапазоны с явной единицей разделяются без изменения операторов; ошибочно включённые в attributes закупочные поля отделяются с corrections. Проверки консервативны, полнота/качество LLM не гарантированы.

PDF с текстовым слоем — text, даже с картинками; сканы — vision при доступной capability. Vision-цитаты/числа не сверены автоматически: `vision_not_verified`, `uncertain=true`, предупреждение. При отсутствии vision нет выдуманного успеха. Смешанный PDF с частичным OCR может потребовать проверки изображений вручную. XLSX formulas не вычисляются: читаются cached values.

8 ожидающих +1 активное задание, один тяжёлый worker. queued/extracting/embedding/searching/done/error. Состояние атомарно сохраняется на диск; после restart незавершённое задание явно error/interrupted, повтор — новой отправкой файлов. Нет automatic resume/distributed queue/нескольких процессов. Не запускайте два экземпляра на одной папке хранения.

Лимиты: 10 файлов, 20 МБ каждый, 60 МБ суммарно, HTTP body64 МБ, 100 позиций/job; PDF40 страниц/20 млн пикселей на страницу скана; текст300000 символов, строка/чанк2000; OOXML100 МБ/10000 частей, XML-часть5 МБ, без DTD/entities/макросов; XLSX200 столбцов/10000 строк на лист,100 разделов. Без legacy/шифрованных файлов.

UUID-имена uploads, файлы не удаляются до обработки. Пароли/внутренние исключения не выдаются браузеру. SQL parameters, textContent, CSP, same-origin POST, TrustedHost. **Нет авторизации, автоматического TTL и изоляции пользователей. Не публикуйте наружу без авторизации/TLS/квот/retention.** Браузеру не нужны модели/GPU, но скорость backend зависит от ресурсов. Нет обещаний1000 позиций/5мин или90%/85% accuracy.

## Публикация на GitHub

Публикуйте содержимое этой папки, включая внутренние modules, static, tests, sample_dataset, package/config/dependency-файлы. [gitignore](<.gitignore>) исключает личные данные/окружение. Не добавляйте соседнюю support-папку, PostgreSQL/SQLite, исходные архивы, Ollama model blobs, пароли и настоящие клиентские документы. Перед публичной публикацией согласуйте авторство/лицензию с командой.
