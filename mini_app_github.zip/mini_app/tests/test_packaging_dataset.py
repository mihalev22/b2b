"""Offline structural/content checks, not model accuracy or retrieval gold tests."""
import json
import unittest
from pathlib import Path
from decimal import Decimal
from mini_app.config import ROOT
from mini_app.extraction import check_upload,text_backend,vision_backend
from mini_app.embedding import migration

class PackagingDatasetTests(unittest.TestCase):
    def setUp(self):
        self.data=ROOT/'sample_dataset'
        self.expected=json.loads((self.data/'expected.json').read_text(encoding='utf-8'))['files']
    def test_internal_dependencies(self):
        for module in (text_backend,vision_backend,migration):
            self.assertEqual(Path(module.__file__).resolve().parent,ROOT/'vendor')
        self.assertEqual(migration.PREFIX,'title: none | text: ')
        self.assertIn('ktru-technical-v2',migration.ALGORITHM)
    def test_required_formats_and_manifest(self):
        for name in ['spec_pdf.pdf','spec_docx.docx','spec_txt.txt','spec_csv.csv','spec_xlsx.xlsx']:
            self.assertEqual(self.expected[name]['expected_count'],8)
            self.assertEqual(len(self.expected[name]['items']),8)
            self.assertEqual(check_upload(self.data/name),self.data/name)
        shared=self.expected['spec_txt.txt']['items'][:3]
        for name in ['spec_pdf.pdf','spec_docx.docx','spec_csv.csv','spec_xlsx.xlsx']:
            compare=self.expected[name]['items'][:3]
            for a,b in zip(shared,compare):
                for key in ['name','brand','model','quantity','unit','required_attributes']:
                    self.assertEqual(a[key],b[key])
        self.assertEqual(shared[1]['name'],shared[2]['name'])
        self.assertNotEqual(shared[1]['quantity'],shared[2]['quantity'])
    def test_readers_and_multisheet(self):
        for name in ['spec_txt.txt','spec_csv.csv','spec_docx.docx','spec_xlsx.xlsx']:
            sections=text_backend.read_document(self.data/name)
            text='\n'.join(content for _,content in sections)
            for item in self.expected[name]['items']:
                self.assertIn(item['name'],text)
                if item['brand']:self.assertIn(item['brand'],text)
                if item['model']:self.assertIn(item['model'],text)
            if name.endswith('xlsx'):self.assertEqual(len(sections),2)
        from openpyxl import load_workbook
        book=load_workbook(self.data/'spec_xlsx.xlsx',read_only=True,data_only=True)
        quantities=[row[4] for sheet in book for row in list(sheet.values)[1:]]
        book.close()
        self.assertEqual(len(quantities),8)
        self.assertTrue(all(isinstance(q,(int,float)) and not isinstance(q,bool) for q in quantities))
        self.assertIn(12.5,quantities)
    def test_text_and_scan_pdf(self):
        import pymupdf
        with pymupdf.open(self.data/'spec_pdf.pdf') as doc:
            self.assertEqual(doc.page_count,2)
            text=' '.join('\n'.join(page.get_text() for page in doc).split())
            for item in self.expected['spec_pdf.pdf']['items']:self.assertIn(item['name'],text)
        with pymupdf.open(self.data/'scan_pdf.pdf') as doc:
            self.assertEqual(doc.page_count,2)
            self.assertTrue(all(not page.get_text().strip() and page.get_images() for page in doc))
    def test_negative_ground_truth(self):
        self.assertEqual((self.data/'empty.txt').stat().st_size,0)
        self.assertEqual(self.expected['injection_only.txt']['expected_count'],0)
        self.assertEqual(self.expected['mixed_injection.txt']['expected_count'],2)
        self.assertEqual((self.data/'unsupported.safe').suffix,'.safe')
        for details in self.expected.values():
            for item in details.get('items',[]):
                self.assertNotIn('ktru_code',item)
                self.assertNotIn('cosine_distance',item)
                if item['quantity'] is not None: self.assertGreaterEqual(Decimal(item['quantity'].replace(',','.')),0)

if __name__=='__main__':unittest.main()
