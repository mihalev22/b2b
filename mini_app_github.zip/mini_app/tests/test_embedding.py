"""Embedding adapter unit tests; deterministic fakes, not model quality."""
import unittest
from unittest.mock import patch
from mini_app.config import Settings
from mini_app.embedding import QueryEmbedder,QUERY_PREFIX,migration

class FakeModel:
    def __init__(self,**kw):self.dim=768;self.fingerprint='test-fingerprint';self.model=kw['model'];self.calls=[]
    def check_identity(self):pass
    def api(self,path,payload):
        self.calls.append(payload)
        return {'embeddings':[[1.]+[0.]*767 for _ in payload['input']]}

class EmbeddingTests(unittest.TestCase):
    def metadata(self):
        return {'dimension':768,'embedding_model_fingerprint':'test-fingerprint','embedding_algorithm':migration.ALGORITHM,'document_prefix':migration.PREFIX,'query_prefix':QUERY_PREFIX}
    def test_batch_query_format_and_no_truncate(self):
        with patch('mini_app.embedding.migration.Ollama',FakeModel):
            e=QueryEmbedder(Settings(),self.metadata());vectors=e.queries(['name']*9)
            self.assertEqual(len(vectors),9);self.assertEqual(len(e.model.calls),2)
            self.assertFalse(e.model.calls[0]['truncate']);self.assertEqual(e.model.calls[0]['input'][0],QUERY_PREFIX+'name')
    def test_refuse_equal_dimension_wrong_identity(self):
        for field,value in [('embedding_model_fingerprint','different'),('embedding_algorithm','other'),('dimension',384),('query_prefix','wrong')]:
            meta=self.metadata();meta[field]=value
            with patch('mini_app.embedding.migration.Ollama',FakeModel):
                with self.assertRaises(RuntimeError):QueryEmbedder(Settings(),meta)
    def test_no_silent_truncation_and_vector_validation(self):
        with patch('mini_app.embedding.migration.Ollama',FakeModel):
            e=QueryEmbedder(Settings(),self.metadata())
            with self.assertRaises(ValueError):e.queries(['x'*12001])
            self.assertEqual(e.model.calls,[])
        for v in [[0.]*768,[float('inf')]+[0.]*767,[1.]*767]:
            with self.assertRaises(ValueError):migration.validate(v,768)
if __name__=='__main__':unittest.main()
