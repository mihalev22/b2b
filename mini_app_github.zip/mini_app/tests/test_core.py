"""Unit/HTTP tests with explicit fakes; not model-quality tests."""
import json
import math
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from fastapi.testclient import TestClient
from mini_app.config import Settings
from mini_app.catalog import Catalog,name_score,normalize_name,rank_candidates,clean_characteristics

class RankingTests(unittest.TestCase):
    def test_normalization(self):
        self.assertEqual(normalize_name(' ЁЖ   USB-3 не 2 '),'еж usb-3 не 2')
        self.assertEqual(name_score('Ёж','еж'),1)
        self.assertLess(name_score('Порт 2 без USB','Порт 4 USB'),1)
    def test_rank_difference_and_scale(self):
        rows=[{'code':'1','name':'Другой товар','cosine_distance':.2},{'code':'2','name':'Монитор','cosine_distance':.25}]
        self.assertEqual(rank_candidates(rows,'Монитор','vector')[0]['code'],'1')
        hybrid=rank_candidates(rows,'Монитор','hybrid')
        self.assertEqual(hybrid[0]['code'],'2')
        self.assertAlmostEqual(hybrid[0]['combined_score'],.8*((1-.25+1)/2)+.2)
        self.assertIsNone(rank_candidates(rows,'Монитор','vector')[0]['name_score'])
    def test_invalid_vectors_and_identity_config(self):
        c=Catalog(Settings())
        for v in [[0.]*768,[1.]*767,[float('nan')]+[1.]*767,[True]+[1.]*767]:
            with self.assertRaises(ValueError):c.search(v,'name')
        with self.assertRaises(ValueError):Settings(pg_database='ktru_vector')
        with self.assertRaises(ValueError):Settings(pg_port=55432)
        with self.assertRaises(ValueError):Settings(vector_weight=.7,name_weight=.2)
        with self.assertRaises(ValueError):Settings(data_dir=Path(__file__).resolve().parents[1]/'static'/'uploads')
    def test_sql_rules(self):
        sql=Catalog().query_sql(True)
        self.assertIn('DISTINCT ON(code)',sql)
        self.assertIn("FROM latest WHERE status='ACTIVE'",sql)
        self.assertIn('version::numeric',sql)
        self.assertIn('source_snapshot_sha256 DESC,source_record_id DESC',sql)
        self.assertIn('embedding <=> %s::vector',sql)
        self.assertNotIn('SELECT *',sql)
    def test_characteristics_allowed_values(self):
        x=clean_characteristics([{'name':'Размер','values':[{'ranges':[{'min_value':2,'min_notation':'>='}],'value_set_entries':[{'concrete_value':3}],'okei_symbol':'мм','raw_json':'SECRET'}]}])
        self.assertNotIn('SECRET',str(x)); self.assertIn('>= 2',str(x));self.assertIn('Варианты',str(x))

class FakeCatalog:
    def __init__(self):self.metadata=None
    def inspect(self):
        self.metadata={'embedding_model_fingerprint':'fake-test'}
        return self.metadata
    def search(self,*args):
        return [{'code':str(i),'name':'Тестовый кандидат','version':'1','status':'ACTIVE','cosine_distance':i/10,'cosine_similarity':1-i/10,'characteristics':[]} for i in range(5)]
class FakeEmbedder:
    def __init__(self,*args):self.model=SimpleNamespace(fingerprint='fake-test')
    def queries(self,texts):return [[1.]+[0.]*767 for _ in texts]

def fake_extract(path,name,progress_callback=None):
    if path.read_bytes()==b'bad':return {'items':[],'errors':[{'source':name,'message':'Модель вернула недостоверную цитату'}]}
    items=[]
    for quantity in [2.,5.]:
        items.append({'name':'Монитор','brand':'','model':'','raw_text':f'Монитор {quantity}','quantity':quantity,'unit':'шт','attributes':[],'corrections':[],'uncertain':False,'source':name,'evidence_type':'text_verified'})
    return {'items':items,'errors':[]}

class JobHTTPTests(unittest.TestCase):
    def setUp(self):
        from mini_app.app import create_app
        from mini_app.jobs import JobManager
        self.tmp=tempfile.TemporaryDirectory()
        self.settings=Settings(data_dir=Path(self.tmp.name))
        self.manager=JobManager(self.settings,FakeCatalog(),FakeEmbedder)
        self.patch=patch('mini_app.jobs.extract_file',side_effect=fake_extract);self.patch.start()
        self.client_context=TestClient(create_app(self.settings,self.manager))
        self.client=self.client_context.__enter__()
    def tearDown(self):
        self.client_context.__exit__(None,None,None);self.patch.stop();self.tmp.cleanup()
    def wait(self,id):
        deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            state=self.client.get('/jobs/'+id+'/results').json()
            if state['status'] in ('done','error'):return state
            time.sleep(.02)
        self.fail('worker timeout')
    def test_multi_files_partial_duplicate_and_http(self):
        result=self.client.post('/jobs',files=[('files',('good.txt',b'good','text/plain')),('files',('bad.csv',b'bad','text/csv')),('files',('empty.txt',b'','text/plain')),('files',('../unsafe.exe',b'x','application/octet-stream'))],data={'ranking':'hybrid','latest_active':'true'})
        self.assertEqual(result.status_code,202)
        state=self.wait(result.json()['job_id'])
        self.assertEqual(state['status'],'done');self.assertEqual(len(state['items']),2)
        self.assertEqual([i['quantity'] for i in state['items']],[2,5])
        self.assertEqual(len(state['errors']),3)
        self.assertEqual(len({c['code'] for c in state['items'][0]['candidates']}),5)
        self.assertTrue(state['latest_active'])
        self.assertEqual(self.client.get('/').status_code,200)
        self.assertEqual(self.client.get('/static/app.js').status_code,200)
        self.assertEqual(self.client.get('/jobs/not-found').status_code,404)
    def test_position_limit_skips_unneeded_model_calls(self):
        self.settings.max_positions=2
        with patch('mini_app.jobs.extract_file',side_effect=fake_extract) as extract:
            result=self.client.post('/jobs',files=[('files',('one.txt',b'good','text/plain')),('files',('two.txt',b'good','text/plain'))])
            state=self.wait(result.json()['job_id'])
        self.assertEqual(len(state['items']),2);self.assertEqual(extract.call_count,1)
        self.assertEqual(state['status'],'done');self.assertIn('не обработан',state['errors'][0]['message'])
    def test_two_jobs_and_queue_bounds(self):
        gate=threading.Event()
        def blocking(*args,**kwargs):gate.wait(3);return fake_extract(*args,**kwargs)
        with patch('mini_app.jobs.extract_file',side_effect=blocking):
            ids=[]
            for _ in range(9):
                response=self.client.post('/jobs',files={'files':('file.txt',b'good','text/plain')})
                self.assertEqual(response.status_code,202);ids.append(response.json()['job_id'])
            self.assertEqual(self.client.post('/jobs',files={'files':('file.txt',b'good','text/plain')}).status_code,429)
            gate.set()
            for id in ids:self.assertEqual(self.wait(id)['status'],'done')
    def test_browser_boundary_body_limit_and_bad_options(self):
        self.assertEqual(self.client.post('/jobs',headers={'Origin':'https://evil.example'},files={'files':('x.txt',b'x')}).status_code,403)
        self.assertEqual(self.client.post('/jobs',headers={'Content-Length':str(65*1024*1024)},content=b'x').status_code,413)
        self.assertEqual(self.client.post('/jobs',files={'files':('x.txt',b'x')},data={'ranking':'invalid'}).status_code,422)
    def test_restart_marks_interrupted(self):
        from mini_app.jobs import JobManager
        # Dedicated manager without worker represents persisted queued work.
        with tempfile.TemporaryDirectory() as tmp:
            s=Settings(data_dir=Path(tmp));m=JobManager(s,FakeCatalog(),FakeEmbedder)
            id=m.reserve();m.submit(id,[],[],'vector',False)
            recovered=JobManager(s,FakeCatalog(),FakeEmbedder)
            state=recovered.get(id)
            self.assertEqual(state['status'],'error');self.assertIn('перезапуском',state['message'])
            self.assertTrue((Path(tmp)/id/'state.json').is_file())

if __name__=='__main__':unittest.main()
