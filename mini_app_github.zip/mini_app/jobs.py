"""Bounded one-worker queue, with atomically persisted local job snapshots."""
import json
import os
import queue
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .catalog import Catalog
from .embedding import QueryEmbedder
from .extraction import extract_file, semantic_text

TERMINAL = {'done','error'}
def now(): return datetime.now(timezone.utc).isoformat()

class JobManager:
    def __init__(self, settings, catalog=None, embedder_factory=QueryEmbedder):
        self.settings = settings
        self.root = settings.data_dir
        self.root.mkdir(parents=True,exist_ok=True)
        self.catalog = catalog or Catalog(settings)
        self.embedder_factory = embedder_factory
        self.embedder = None
        self.states = {}
        self.lock = threading.RLock()
        self.reservations = 0
        self.queue = queue.Queue(maxsize=settings.queue_size + 1)
        self.stop_event = threading.Event()
        self.thread = None
        self.recover()
    def recover(self):
        for path in self.root.glob('*/state.json'):
            try:
                state = json.loads(path.read_text(encoding='utf-8'))
                if str(uuid.UUID(state['job_id'])) != path.parent.name: continue
                if state['status'] not in TERMINAL:
                    state['status'] = 'error'
                    state['message'] = 'Задание прервано перезапуском. Отправьте файлы повторно.'
                    state['errors'].append({'source':'задание','message':state['message']})
                self.states[state['job_id']] = state
                self._save(state)
            except (ValueError,KeyError,OSError):
                # Corrupt local state must not become a successful job.
                continue
    def _save(self, state):
        directory = self.root / state['job_id']
        directory.mkdir(exist_ok=True)
        tmp = directory / 'state.tmp'
        with tmp.open('w',encoding='utf-8') as out:
            json.dump(state,out,ensure_ascii=False,allow_nan=False)
            out.flush(); os.fsync(out.fileno())
        tmp.replace(directory / 'state.json')
    def reserve(self):
        with self.lock:
            active = sum(x['status'] not in TERMINAL for x in self.states.values())
            if active + self.reservations >= self.settings.queue_size + 1:
                return None
            self.reservations += 1
            job_id = str(uuid.uuid4())
            (self.root / job_id).mkdir()
            return job_id
    def release(self):
        with self.lock: self.reservations -= 1
    def submit(self, job_id, files, errors, ranking, latest_active):
        state = {'job_id':job_id,'status':'queued','created_at':now(),'updated_at':now(),
            'current_file':None,'processed_positions':0,'total_positions':0,'timings':{},
            'errors':errors,'items':[],'ranking':ranking,'latest_active':latest_active,
            'search_kind':'exact','weights':{'vector':self.settings.vector_weight,'name':self.settings.name_weight},
            'message':'В очереди','_files':files}
        with self.lock:
            self.states[job_id] = state
            self._save(state)
            self.reservations -= 1
            self.queue.put_nowait(job_id)
        return self.public(state)
    def update(self, job_id, **changes):
        with self.lock:
            state = self.states[job_id]
            if 'status' in changes and changes['status'] != state['status']:
                changes['stage_started_at'] = now()
            state.update(changes,updated_at=now())
            self._save(state)
    def public(self,state, include_items=False):
        with self.lock:
            return json.loads(json.dumps({k:v for k,v in state.items() if not k.startswith('_') and (include_items or k!='items')},ensure_ascii=False))
    def get(self,job_id,include_items=False):
        with self.lock:
            state = self.states.get(job_id)
            return self.public(state,include_items) if state else None
    def all(self):
        with self.lock:
            return [self.public(s) for s in sorted(self.states.values(),key=lambda s:s['created_at'],reverse=True)]
    def start(self):
        self.thread = threading.Thread(target=self.worker,name='ktru-single-worker',daemon=True)
        self.thread.start()
    def close(self):
        self.stop_event.set()
        # No queue task is advertised as durable/resumed on next process start.
        if self.thread: self.thread.join(timeout=2)
    def worker(self):
        while not self.stop_event.is_set():
            try: job_id = self.queue.get(timeout=.3)
            except queue.Empty: continue
            try: self.process(job_id)
            except Exception:
                state = self.states[job_id]
                errors = list(state['errors']) + [{'source':state['current_file'] or 'задание','message':'Каталог или Ollama недоступны, либо проверка совместимости не пройдена. Проверьте /health и конфигурацию сервера.'}]
                self.update(job_id,status='error',errors=errors,message='Обработка прервана; извлечённые позиции сохранены')
            finally: self.queue.task_done()
    def process(self,job_id):
        state = self.states[job_id]
        timings = {}; errors = list(state['errors']); items = []
        if not state['_files']:
            self.update(job_id,status='error',message='Нет допустимых непустых файлов',errors=errors)
            return
        self.update(job_id,status='extracting',message='Проверка каталога и совместимости моделей')
        t = time.perf_counter()
        metadata = self.catalog.inspect()
        if self.embedder is None: self.embedder = self.embedder_factory(self.settings,metadata)
        elif self.embedder.model.fingerprint != metadata['embedding_model_fingerprint']:
            raise RuntimeError('Catalogue identity changed')
        timings['checking'] = time.perf_counter()-t
        self.update(job_id,status='extracting',message='Извлечение отдельных позиций',timings=dict(timings))
        t = time.perf_counter()
        for file in state['_files']:
            if len(items)>=self.settings.max_positions:
                errors.append({'source':file['filename'],'message':'Лимит задания: 100 позиций. Этот файл не обработан.'})
                self.update(job_id,errors=list(errors))
                continue
            self.update(job_id,current_file=file['filename'])
            def progress(section, count):
                self.update(job_id,message='Извлечение: '+str(section),total_positions=len(items)+count)
            try:
                extracted = extract_file(self.root / job_id / file['stored_name'],file['filename'],progress_callback=progress)
                errors.extend(extracted['errors'])
                room = self.settings.max_positions-len(items)
                if len(extracted['items']) > room:
                    errors.append({'source':file['filename'],'message':'Лимит задания: 100 позиций. Часть позиций не обработана.'})
                for item in extracted['items'][:max(0,room)]:
                    item['position_id'] = len(items)+1
                    item['candidates'] = []
                    items.append(item)
            except Exception:
                errors.append({'source':file['filename'],'message':'Файл не удалось прочитать или проверить. Проверьте формат, лимиты и доступность модели.'})
            self.update(job_id,items=list(items),errors=list(errors),total_positions=len(items))
        timings['extracting'] = time.perf_counter()-t
        if not items:
            self.update(job_id,status='error',timings=timings,errors=errors or [{'source':'задание','message':'Товарные позиции не найдены'}],message='Нет подтверждённых товарных позиций')
            return
        self.update(job_id,status='embedding',timings=dict(timings),message='Совместимые query-эмбеддинги',current_file=None)
        t = time.perf_counter()
        # Batch across positions; isolate failures so valid positions still get results.
        embedded = []
        for start in range(0,len(items),8):
            batch = items[start:start+8]
            try:
                vectors = self.embedder.queries([semantic_text(i) for i in batch])
                embedded.extend(zip(batch,vectors))
            except Exception:
                for item in batch:
                    try: embedded.append((item,self.embedder.queries([semantic_text(item)])[0]))
                    except Exception:
                        errors.append({'source':item['source'],'message':f"Позиция {item['position_id']}: эмбеддинг не получен; обрезание входа запрещено."})
            self.update(job_id,errors=list(errors),processed_positions=len(embedded))
        timings['embedding'] = time.perf_counter()-t
        self.update(job_id,status='searching',timings=dict(timings),processed_positions=0,message='Точный поиск в public.ktru')
        t = time.perf_counter()
        searched = 0
        for item,vector in embedded:
            self.update(job_id,current_file=item['source'])
            started = time.perf_counter()
            try:
                item['candidates'] = self.catalog.search(vector,item['name'],state['ranking'],state['latest_active'])
                item['search_seconds'] = time.perf_counter()-started
                if len(item['candidates']) < 5:
                    errors.append({'source':item['source'],'message':'Доступно менее пяти различных кодов.'})
                searched += 1
            except Exception:
                errors.append({'source':item['source'],'message':f"Позиция {item['position_id']}: поиск в каталоге не выполнен."})
            self.update(job_id,items=list(items),errors=list(errors),processed_positions=searched)
        timings['searching'] = time.perf_counter()-t
        timings['total'] = sum(timings.values())
        self.update(job_id,status='done' if searched else 'error',timings=timings,current_file=None,message='Готово с частичными ошибками' if errors else 'Готово',items=items,errors=errors)
