"""FastAPI: local upload UI and asynchronous read-only catalogue matching."""
import asyncio
import json
from contextlib import asynccontextmanager
from pathlib import Path
import uuid
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from .config import Settings, ROOT
from .jobs import JobManager

ALLOWED = {'.pdf','.docx','.txt','.csv','.xlsx'}

class RequestLimitMiddleware:
    def __init__(self,app,limit): self.app,self.limit = app,limit
    async def __call__(self,scope,receive,send):
        if scope['type'] != 'http': return await self.app(scope,receive,send)
        headers = dict(scope['headers'])
        try: length = int(headers.get(b'content-length',b'0'))
        except ValueError: length = self.limit+1
        if length > self.limit:
            await send({'type':'http.response.start','status':413,'headers':[(b'content-type',b'application/json')]})
            await send({'type':'http.response.body','body':json.dumps({'detail':'Запрос превышает 64 МБ'}).encode()})
            return
        consumed = 0
        async def limited_receive():
            nonlocal consumed
            message = await receive()
            consumed += len(message.get('body',b''))
            if consumed > self.limit: raise HTTPException(413,'Запрос превышает 64 МБ')
            return message
        await self.app(scope,limited_receive,send)

def create_app(settings=None,manager=None):
    settings = settings or Settings()
    @asynccontextmanager
    async def lifespan(app):
        app.state.manager = manager or JobManager(settings)
        app.state.manager.start()
        yield
        app.state.manager.close()
    app = FastAPI(title='КТРУ · Поиск позиций',lifespan=lifespan)
    app.add_middleware(TrustedHostMiddleware,allowed_hosts=['localhost','127.0.0.1','[::1]','testserver'])
    app.add_middleware(RequestLimitMiddleware,limit=64*1024*1024)
    @app.middleware('http')
    async def browser_boundary(request,call_next):
        origin = request.headers.get('origin')
        if request.method not in ('GET','HEAD','OPTIONS') and origin and origin.rstrip('/') != str(request.base_url).rstrip('/'):
            from fastapi.responses import JSONResponse
            return JSONResponse({'detail':'Запрос с другого сайта запрещён'},status_code=403)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Content-Security-Policy'] = "default-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        response.headers['Cache-Control'] = 'no-store'
        return response
    def jm(): return app.state.manager
    @app.get('/')
    def index(): return FileResponse(ROOT / 'static' / 'index.html')
    app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')
    @app.get('/health')
    def health():
        import httpx
        meta = jm().catalog.metadata
        try:
            with httpx.Client(timeout=5,trust_env=False) as client:
                tags = client.get(settings.ollama_url+'/api/tags'); tags.raise_for_status()
                models = tags.json()['models']
            from .vendor.step1_text_docs import TEXT_MODEL
            installed = {m['name']:m.get('digest') for m in models}
            ready = TEXT_MODEL in installed and settings.embedding_model in installed and bool(meta) and bool(jm().embedder)
            return {'status':'ready' if ready else 'not_ready','database_checked':bool(meta),'metadata':meta,'embedding_model':settings.embedding_model,'text_model':TEXT_MODEL,'models_installed':TEXT_MODEL in installed and settings.embedding_model in installed,'message':'Каталог проверяется при первом задании' if not meta else 'Локальные модели и read-only каталог'}
        except Exception:
            return {'status':'not_ready','database_checked':bool(meta),'message':'Ollama недоступна или модели не установлены'}
    @app.post('/jobs',status_code=202)
    async def submit(files:list[UploadFile]=File(...),ranking:str=Form('vector'),latest_active:bool=Form(False)):
        if ranking not in ('vector','hybrid'): raise HTTPException(422,'Неизвестный режим ранжирования')
        if not 1 <= len(files) <= settings.max_files: raise HTTPException(422,'От 1 до 10 файлов в задании')
        job_id = jm().reserve()
        if job_id is None:
            for file in files: await file.close()
            raise HTTPException(429,'Очередь заполнена. Подождите завершения текущих заданий.')
        accepted = []; errors = []; total = 0
        committed = False
        try:
            for upload in files:
                name = Path((upload.filename or 'без имени').replace('\\','/')).name[:200]
                ext = Path(name).suffix.casefold()
                if ext not in ALLOWED:
                    errors.append({'source':name,'message':'Неподдерживаемый формат. Допустимы PDF, DOCX, TXT, CSV, XLSX.'})
                    continue
                stored = str(uuid.uuid4())+ext
                path = jm().root/job_id/stored
                size = 0; oversized = False
                with path.open('wb') as output:
                    while chunk := await upload.read(1024*1024):
                        size += len(chunk); total += len(chunk)
                        if size > settings.max_file_bytes: oversized = True; break
                        if total > settings.max_job_bytes: raise HTTPException(413,'Суммарный размер файлов превышает 60 МБ')
                        output.write(chunk)
                if oversized or not size:
                    errors.append({'source':name,'message':'Файл превышает 20 МБ' if oversized else 'Пустой файл'})
                    # Invalid upload kept under safe UUID until manual local cleanup.
                    continue
                accepted.append({'filename':name,'stored_name':stored})
            state = jm().submit(job_id,accepted,errors,ranking,latest_active)
            committed = True
            return {'job_id':state['job_id'],'status':state['status']}
        finally:
            for file in files: await file.close()
            if not committed: jm().release()
    @app.get('/jobs')
    def list_jobs(): return {'jobs':jm().all()}
    @app.get('/jobs/{job_id}')
    def job(job_id:str):
        state = jm().get(job_id)
        if state is None: raise HTTPException(404,'Задание не найдено')
        return state
    @app.get('/jobs/{job_id}/results')
    def results(job_id:str):
        state = jm().get(job_id,include_items=True)
        if state is None: raise HTTPException(404,'Задание не найдено')
        return state
    return app

app = create_app()
