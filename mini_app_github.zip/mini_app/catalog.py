"""Separate strictly read-only adapter for the existing large public.ktru."""
import math
import json
from decimal import Decimal
import re
from difflib import SequenceMatcher
import psycopg
from psycopg.rows import dict_row
from .config import Settings

ALGORITHM = 'ktru-technical-v2:characteristic-pack4000:adaptive-boundaries:utf8byte-weighted-l2'
NUMERIC_VERSION = "CASE WHEN version ~ '^[0-9]+([.][0-9]+)?$' THEN version::numeric END"
FIELDS = 'code,name,version,status,source_snapshot_sha256,source_record_id'
# Project nested attributes in PostgreSQL: raw XML/JSON trees never cross into the app.
CHARACTERISTICS_SQL = """SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'name',c->'name','is_required',c->'is_required','actual',c->'actual','choice_type',c->'choice_type',
    'values',(SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'quality_description',v->'quality_description','okei_symbol',v->'okei_symbol','okei_name',v->'okei_name',
        'ranges',(SELECT COALESCE(jsonb_agg(jsonb_build_object(
            'min_value',r->'min_value','min_notation',r->'min_notation',
            'max_value',r->'max_value','max_notation',r->'max_notation')),'[]'::jsonb)
            FROM jsonb_array_elements(COALESCE(v->'ranges','[]'::jsonb)) r),
        'value_set_entries',(SELECT COALESCE(jsonb_agg(jsonb_build_object('concrete_value',s->'concrete_value')),'[]'::jsonb)
            FROM jsonb_array_elements(COALESCE(v->'value_set_entries','[]'::jsonb)) s)
        )),'[]'::jsonb) FROM jsonb_array_elements(COALESCE(c->'values','[]'::jsonb)) v)
    )),'[]'::jsonb) AS characteristics
    FROM public.ktru k CROSS JOIN LATERAL jsonb_array_elements(k.characteristics) c
    WHERE k.source_snapshot_sha256=%s AND k.source_record_id=%s"""

def normalize_name(text):
    return ' '.join(str(text if text is not None else '').casefold().replace('ё', 'е').split())

def name_score(a, b):
    a, b = normalize_name(a), normalize_name(b)
    if not a or not b: return 0.0
    # Numbers, model markings and negations survive tokenisation; no stopword dictionary.
    aa, bb = set(re.findall(r'[\w]+(?:[-.,/][\w]+)*', a)), set(re.findall(r'[\w]+(?:[-.,/][\w]+)*', b))
    jaccard = len(aa & bb) / len(aa | bb) if aa | bb else 0.0
    return .5 * jaccard + .5 * SequenceMatcher(None, a, b, autojunk=False).ratio()

def rank_candidates(rows, name, mode, vector_weight=.8, name_weight=.2):
    out = []
    for row in rows:
        item = dict(row)
        distance = float(item['cosine_distance'])
        if not math.isfinite(distance) or not -1e-6 <= distance <= 2 + 1e-6:
            raise ValueError('Invalid cosine distance')
        item['cosine_distance'] = distance
        item['cosine_similarity'] = 1 - distance
        # Both signals use [0,1], retaining signed cosine separately.
        item['vector_score'] = max(0., min(1., (item['cosine_similarity'] + 1) / 2))
        item['name_score'] = name_score(name, item['name']) if mode == 'hybrid' else None
        item['combined_score'] = (vector_weight * item['vector_score'] + name_weight * item['name_score']) if mode == 'hybrid' else None
        out.append(item)
    if mode == 'hybrid':
        out.sort(key=lambda x: (-x['combined_score'], x['cosine_distance'], x['code']))
    else:
        out.sort(key=lambda x: (x['cosine_distance'], x['code']))
    return out[:5]

def clean_characteristics(characteristics):
    result = []
    for c in characteristics or []:
        values = []
        for v in c.get('values', []):
            parts = []
            if v.get('quality_description') is not None: parts.append(str(v['quality_description']))
            unit = v.get('okei_symbol') or v.get('okei_name') or ''
            for r in v.get('ranges', []):
                bounds = []
                for side, label in [('min', 'min'), ('max', 'max')]:
                    if r.get(side + '_value') is not None:
                        bounds.append(f"{label} {r.get(side + '_notation') or '(оператор не указан)'} {r[side + '_value']}")
                if bounds: parts.append('; '.join(bounds))
            entries = [str(s['concrete_value']) for s in v.get('value_set_entries', []) if s.get('concrete_value') is not None]
            if entries: parts.append('Варианты: ' + ' / '.join(entries))
            if unit: parts.append(str(unit))
            if parts: values.append(' · '.join(parts))
        result.append({'name': str(c.get('name') or 'Без наименования'), 'required': True if c.get('is_required') in (True,1,'1','true') else False if c.get('is_required') in (False,0,'0','false') else None, 'choice_type': c.get('choice_type'), 'values': values, 'actual': c.get('actual')})
    return result

class Catalog:
    def __init__(self, settings=None):
        self.settings = settings or Settings()
        self.metadata = None
    def connect(self):
        s = self.settings
        # libpq reads PGPASSWORD / PGPASSFILE itself; no password in code or logs.
        conn = psycopg.connect(host=s.pg_host, port=s.pg_port, dbname=s.pg_database, user=s.pg_user,
            connect_timeout=10, application_name='ktru_mini_readonly',
            options='-c default_transaction_read_only=on -c statement_timeout=120000', row_factory=dict_row)
        psycopg.types.json.set_json_loads(lambda raw: json.loads(raw,parse_float=Decimal),conn)
        return conn
    def inspect(self):
        with self.connect() as conn:
            identity = conn.execute("SELECT current_database() AS database,current_user AS username,current_setting('transaction_read_only') AS read_only,inet_server_port() AS port").fetchone()
            if identity['database'] != 'ktru' or identity['username'] != 'ai_agent' or identity['read_only'] != 'on':
                raise RuntimeError('Wrong database identity or writable transaction')
            dim = conn.execute("SELECT format_type(atttypid,atttypmod) AS type FROM pg_attribute WHERE attrelid='public.ktru'::regclass AND attname='embedding'").fetchone()
            if not dim or dim['type'] != 'vector(768)': raise RuntimeError('Unexpected embedding dimension')
            meta = conn.execute('SELECT embedding_model,embedding_model_fingerprint,embedding_algorithm,embedding_status,count(*) AS records FROM public.ktru GROUP BY 1,2,3,4').fetchall()
            if len(meta) != 1 or meta[0]['embedding_model'] != self.settings.embedding_model or meta[0]['embedding_algorithm'] != ALGORITHM or meta[0]['embedding_status'] != 'ready' or not meta[0]['embedding_model_fingerprint']:
                raise RuntimeError('Catalogue embedding identities are not compatible')
            counts = conn.execute("SELECT count(DISTINCT code) AS codes,count(*) FILTER(WHERE embedding IS NULL) AS missing,count(*) FILTER(WHERE code IS NULL OR btrim(code)='') AS invalid_codes,count(*) FILTER(WHERE version IS NULL OR version !~ '^[0-9]+([.][0-9]+)?$') AS invalid_versions FROM public.ktru").fetchone()
            if counts['missing'] or counts['invalid_versions'] or counts['invalid_codes']: raise RuntimeError('Catalogue has missing vectors, codes or nonnumeric versions')
            self.metadata = {**identity, **meta[0], **counts, 'dimension':768, 'search_kind':'exact', 'document_prefix':'title: none | text: ', 'query_prefix':'task: search result | query: '}
            return self.metadata
    def query_sql(self, latest_active):
        # Materialisation separates scoring from the HNSW access path. Explicit scan
        # settings below additionally forbid ANN. Dedup is exhaustive, not a small pool.
        if latest_active:
            eligible = f"""latest AS MATERIALIZED (
                SELECT DISTINCT ON(code) {FIELDS},embedding FROM public.ktru
                ORDER BY code,{NUMERIC_VERSION} DESC NULLS LAST,source_snapshot_sha256 DESC,source_record_id DESC),
                eligible AS MATERIALIZED (SELECT {FIELDS},embedding FROM latest WHERE status='ACTIVE'),"""
        else:
            eligible = ''
        source = 'eligible' if latest_active else 'public.ktru'
        return f"""WITH {eligible} scored AS MATERIALIZED (
            SELECT {FIELDS}, embedding <=> %s::vector AS cosine_distance FROM {source}),
            best AS (SELECT DISTINCT ON(code) {FIELDS},cosine_distance FROM scored
                ORDER BY code,cosine_distance,{NUMERIC_VERSION} DESC NULLS LAST,source_snapshot_sha256 DESC,source_record_id DESC)
            SELECT {FIELDS},cosine_distance FROM best ORDER BY cosine_distance,code LIMIT %s"""
    def search(self, vector, name, mode='vector', latest_active=False):
        if mode not in ('vector', 'hybrid'): raise ValueError('Unknown ranking mode')
        if len(vector) != 768 or any(isinstance(v, bool) or not isinstance(v, (float,int)) or not math.isfinite(v) for v in vector) or not math.isfinite(math.hypot(*vector)) or math.hypot(*vector) <= 1e-12:
            raise ValueError('Invalid query vector')
        literal = '[' + ','.join(format(v, '.17g') for v in vector) + ']'
        pool = self.settings.hybrid_pool if mode == 'hybrid' else 5
        if self.metadata is None: raise RuntimeError('Catalogue identity has not been checked')
        with self.connect() as conn:
            conn.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
            identities=conn.execute('SELECT embedding_model,embedding_model_fingerprint,embedding_algorithm,embedding_status,count(*) AS records,count(*) FILTER(WHERE embedding IS NULL) AS missing_vectors FROM public.ktru GROUP BY 1,2,3,4').fetchall()
            keys=('embedding_model','embedding_model_fingerprint','embedding_algorithm','embedding_status','records')
            if len(identities)!=1 or identities[0]['missing_vectors'] or any(identities[0][key]!=self.metadata[key] for key in keys):
                raise RuntimeError('Catalogue identity changed during job; refusing mixed vector spaces')
            conn.execute('SET LOCAL enable_indexscan = off')
            conn.execute('SET LOCAL enable_bitmapscan = off')
            rows = conn.execute(self.query_sql(latest_active), (literal,pool)).fetchall()
            result = rank_candidates(rows, name, mode, self.settings.vector_weight, self.settings.name_weight)
            # Scoring has completed without ANN; primary-key lookup may use B-tree.
            conn.execute('SET LOCAL enable_indexscan = on')
            conn.execute('SET LOCAL enable_bitmapscan = on')
            for row in result:
                raw = conn.execute(CHARACTERISTICS_SQL, (row['source_snapshot_sha256'],row['source_record_id'])).fetchone()
                row['characteristics'] = clean_characteristics(raw['characteristics'])
                row.pop('source_snapshot_sha256'); row.pop('source_record_id')
            return result
    def explain(self, vector, latest_active=False):
        literal = '[' + ','.join(map(str,vector)) + ']'
        with self.connect() as conn:
            conn.execute('SET LOCAL enable_indexscan = off'); conn.execute('SET LOCAL enable_bitmapscan = off')
            return conn.execute('EXPLAIN (FORMAT JSON) '+self.query_sql(latest_active),(literal,5)).fetchone()['QUERY PLAN']
