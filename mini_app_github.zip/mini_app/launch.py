"""Run from Result: python -m mini_app.launch [--from-vector-db]."""
import argparse
import os
from pathlib import Path
from urllib.parse import urlsplit,unquote

def load_vector_db_profile():
    import yaml
    profile = os.getenv('DSH_PROFILE_DIR')
    if not profile: raise RuntimeError('DSH_PROFILE_DIR is unavailable; configure libpq environment instead')
    config = yaml.safe_load((Path(profile)/'cordis.patch.yml').read_text(encoding='utf-8'))
    server = next(x['config'] for x in config if x.get('config',{}).get('serverName') == 'vector-db')
    uri = urlsplit(server['env']['DATABASE_URI'])
    if uri.path != '/ktru' or uri.username != 'ai_agent' or uri.port == 55432:
        raise RuntimeError('vector-db is not the required large catalogue')
    os.environ.update(PGHOST='127.0.0.1' if uri.hostname=='localhost' else uri.hostname,PGPORT=str(uri.port or 5432),PGDATABASE='ktru',PGUSER='ai_agent')
    if uri.password: os.environ['PGPASSWORD'] = unquote(uri.password)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--from-vector-db',action='store_true',help='Read existing vector-db connection profile into process environment only')
    parser.add_argument('--port',type=int,default=8008)
    args = parser.parse_args()
    if args.from_vector_db: load_vector_db_profile()
    import uvicorn
    uvicorn.run('mini_app.app:app',host='127.0.0.1',port=args.port,workers=1,access_log=False)
if __name__=='__main__': main()
