"""Reuse the actual migration model implementation and its query format."""
from .vendor import embeddings as migration
QUERY_PREFIX = 'task: search result | query: '

class QueryEmbedder:
    def __init__(self, settings, metadata):
        self.model = migration.Ollama(url=settings.ollama_url,model=settings.embedding_model,workers=1,batch_size=8)
        if self.model.dim != metadata['dimension'] or self.model.fingerprint != metadata['embedding_model_fingerprint'] or migration.ALGORITHM != metadata['embedding_algorithm']:
            raise RuntimeError('Embedding model fingerprint, dimension or document algorithm mismatch')
        if migration.PREFIX != metadata['document_prefix'] or QUERY_PREFIX != metadata['query_prefix']:
            raise RuntimeError('Embedding input format mismatch')
    def queries(self, texts):
        if any(not text.strip() or len(text) > 12000 for text in texts):
            raise ValueError('Empty or oversized position description; no truncation permitted')
        self.model.check_identity()
        vectors = []
        for start in range(0,len(texts),8):
            batch = texts[start:start+8]
            # Exactly migration.Ollama.query() format, batched rather than document prefix.
            response = self.model.api('/api/embed', {'model':self.model.model, 'input':[QUERY_PREFIX + t for t in batch], 'truncate':False})
            raw = response.get('embeddings', [])
            if len(raw) != len(batch): raise RuntimeError('Incorrect embedding batch size')
            vectors.extend(migration.validate(v,self.model.dim) for v in raw)
        self.model.check_identity()
        return vectors
