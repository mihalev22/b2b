'use strict';
(() => {
  const $ = (id) => document.getElementById(id);
  const ui = { form: $('upload-form'), files: $('files'), drop: $('drop-zone'), selected: $('selected-files'), submit: $('submit-button'), feedback: $('upload-feedback'), queue: $('job-list'), queueFeedback: $('queue-feedback'), summary: $('job-summary'), context: $('result-context'), errors: $('result-errors'), body: $('result-body'), count: $('result-count') };
  const state = { files: [], jobs: new Map(), selectedId: null, results: new Map(), resultRequests: new Map(), submitting: false, polling: false, viewToken: 0 };
  const statusNames = { queued: 'В очереди', extracting: 'Извлечение', embedding: 'Векторизация', searching: 'Поиск кодов', done: 'Готово', error: 'Ошибка' };
  const terminal = (job) => ['done', 'error'].includes(job.status);
  const list = (value) => Array.isArray(value) ? value : [];
  function text(value) {
    if (value === null || value === undefined) return '';
    if (typeof value === 'object') {
      if (Array.isArray(value)) return value.map(text).filter(Boolean).join('; ');
      return Object.entries(value).map(([key, val]) => `${key}: ${text(val)}`).join(' · ');
    }
    return String(value);
  }
  function node(tag, className, content) {
    const result = document.createElement(tag);
    if (className) result.className = className;
    if (content !== undefined) result.textContent = text(content);
    return result;
  }
  function numeric(value) { return value !== null && value !== '' && value !== undefined && Number.isFinite(Number(value)) ? Number(value) : null; }
  function metric(value) { const n = numeric(value); return n === null ? '—' : n.toLocaleString('ru-RU', { maximumFractionDigits: 4, minimumFractionDigits: 3 }); }
  function date(value) { const d = new Date(value); return Number.isNaN(d.getTime()) ? text(value) : d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); }
  function feedback(message, error = false) { ui.feedback.textContent = message; ui.feedback.classList.toggle('is-error', error); }
  async function request(path, options = {}) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), options.method === 'POST' ? 120000 : 20000);
    try {
      const response = await fetch(path, { ...options, signal: controller.signal, headers: { Accept: 'application/json', ...options.headers } });
      let data;
      try { data = await response.json(); } catch { throw new Error(`Сервис вернул ответ без JSON (HTTP ${response.status})`); }
      if (!response.ok) throw new Error(text(data.detail || data.message || `HTTP ${response.status}`));
      return data;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('Сервис не ответил вовремя. Обновите очередь перед повторной отправкой.');
      throw error;
    } finally { window.clearTimeout(timeout); }
  }
  function fileKey(file) { return `${file.name}/${file.size}/${file.lastModified}`; }
  function addFiles(files) {
    const keys = new Set(state.files.map(fileKey));
    for (const file of files) if (!keys.has(fileKey(file))) { state.files.push(file); keys.add(fileKey(file)); }
    ui.files.value = '';
    renderFiles();
    if (files.length) feedback(`Выбрано файлов: ${state.files.length}`);
  }
  function renderFiles() {
    ui.selected.replaceChildren();
    for (const file of state.files) {
      const row = node('li', 'selected-file');
      const info = node('span', 'file-info');
      info.append(node('span', 'file-name', file.name), node('span', 'file-size', `${(file.size / 1024).toLocaleString('ru-RU', { maximumFractionDigits: 1 })} КБ`));
      const remove = node('button', 'remove-file', '×');
      remove.type = 'button'; remove.setAttribute('aria-label', `Удалить файл ${file.name}`);
      remove.addEventListener('click', () => { state.files = state.files.filter((entry) => entry !== file); renderFiles(); });
      row.append(info, remove); ui.selected.append(row);
    }
    ui.submit.disabled = state.submitting || !state.files.length;
  }
  ui.files.addEventListener('change', () => addFiles(Array.from(ui.files.files)));
  let dragDepth = 0;
  ui.drop.addEventListener('dragenter', (event) => { event.preventDefault(); dragDepth++; ui.drop.classList.add('dragging'); });
  ui.drop.addEventListener('dragover', (event) => { event.preventDefault(); if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy'; });
  ui.drop.addEventListener('dragleave', (event) => { event.preventDefault(); dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) ui.drop.classList.remove('dragging'); });
  ui.drop.addEventListener('drop', (event) => { event.preventDefault(); dragDepth = 0; ui.drop.classList.remove('dragging'); addFiles(Array.from(event.dataTransfer?.files || [])); });
  // Prevent accidentally navigating away when files miss the drop target.
  window.addEventListener('dragover', (event) => { if (Array.from(event.dataTransfer?.types || []).includes('Files')) event.preventDefault(); });
  window.addEventListener('drop', (event) => { if (Array.from(event.dataTransfer?.types || []).includes('Files')) event.preventDefault(); });
  ui.form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (state.submitting || !state.files.length) return;
    const submitted = [...state.files];
    const form = new FormData();
    submitted.forEach((file) => form.append('files', file));
    form.append('ranking', ui.form.elements.ranking.value);
    form.append('latest_active', $('latest-active').checked ? 'true' : 'false');
    state.submitting = true; renderFiles(); ui.submit.setAttribute('aria-busy', 'true'); feedback('Передаём документы…');
    try {
      const data = await request('/jobs', { method: 'POST', body: form });
      if (!data.job_id) throw new Error('Сервис не вернул идентификатор задачи. Проверьте очередь перед повторной отправкой.');
      const id = String(data.job_id);
      state.jobs.set(id, { job_id: id, status: 'queued', created_at: new Date().toISOString(), processed_positions: 0, total_positions: 0 });
      const sentKeys = new Set(submitted.map(fileKey));
      state.files = state.files.filter((file) => !sentKeys.has(fileKey(file)));
      feedback('Задача поставлена в очередь. Можно отправить следующие документы.');
      selectJob(id); renderQueue(); void poll();
    } catch (error) { feedback(`Не удалось отправить: ${error.message}`, true); }
    finally { state.submitting = false; ui.submit.removeAttribute('aria-busy'); renderFiles(); }
  });
  function mergeJobs(jobs) { for (const job of jobs) if (job?.job_id) state.jobs.set(String(job.job_id), job); }
  function sortedJobs() { return [...state.jobs.values()].sort((a, b) => (Date.parse(b.created_at) || 0) - (Date.parse(a.created_at) || 0)); }
  function renderQueue() {
    const focusedId = document.activeElement?.dataset?.jobId;
    ui.queue.replaceChildren();
    const jobs = sortedJobs();
    if (!jobs.length) { ui.queue.append(node('p', 'empty-queue', 'Пока нет задач')); return; }
    for (const job of jobs) {
      const id = String(job.job_id);
      const button = node('button', `job-button${id === state.selectedId ? ' selected' : ''}`);
      button.type = 'button'; button.dataset.jobId = id; button.setAttribute('aria-pressed', String(id === state.selectedId));
      const top = node('span', 'job-topline');
      top.append(node('span', 'job-id', `ЗАДАЧА ${id.slice(0, 8)}`), node('span', `status-label ${['done', 'error'].includes(job.status) ? job.status : ''}`, statusNames[job.status] || job.status));
      button.append(top);
      if (job.current_file) button.append(node('span', 'job-current', job.current_file));
      const progress = node('span', 'job-progress');
      const processed = Math.max(0, numeric(job.processed_positions) || 0), total = Math.max(0, numeric(job.total_positions) || 0);
      progress.append(node('span', '', `${processed} / ${total || '—'} поз.`), node('span', '', job.created_at ? date(job.created_at) : ''));
      button.append(progress);
      const bar = node('div', 'job-bar'); const fill = node('div', 'job-bar-fill');
      fill.style.width = `${job.status === 'done' ? 100 : total ? Math.min(100, processed / total * 100) : 0}%`; bar.append(fill); button.append(bar);
      button.addEventListener('click', () => selectJob(id)); ui.queue.append(button);
      if (focusedId === id) button.focus({ preventScroll: true });
    }
  }
  async function refreshJobs() {
    try {
      const data = await request('/jobs'); mergeJobs(list(data.jobs));
      ui.queueFeedback.textContent = ''; renderQueue();
      if (!state.selectedId && state.jobs.size) selectJob(String(sortedJobs()[0].job_id));
      else renderSelected();
    } catch (error) { ui.queueFeedback.textContent = `Очередь недоступна: ${error.message}. Повторим автоматически.`; }
  }
  async function poll() {
    if (state.polling) return;
    state.polling = true;
    try {
      const active = [...state.jobs.values()].filter((job) => !terminal(job));
      const ids = new Set(active.map((job) => String(job.job_id)));
      if (state.selectedId) ids.add(state.selectedId);
      const settled = await Promise.allSettled([...ids].map(async (id) => {
        const job = await request(`/jobs/${encodeURIComponent(id)}`);
        if (job.job_id) state.jobs.set(id, job);
      }));
      if (settled.some((result) => result.status === 'rejected')) ui.queueFeedback.textContent = 'Не удалось обновить часть задач. Повторим автоматически.';
      else ui.queueFeedback.textContent = '';
      renderQueue(); renderSelected();
    } finally { state.polling = false; }
  }
  $('refresh-jobs').addEventListener('click', async () => { $('refresh-jobs').disabled = true; await refreshJobs(); await poll(); $('refresh-jobs').disabled = false; });
  function selectJob(id) {
    state.selectedId = id; state.viewToken++; renderQueue();
    ui.body.replaceChildren(); ui.body.dataset.renderedJob = ''; ui.body.dataset.loadingJob = ''; ui.errors.replaceChildren(); ui.errors.hidden = true; ui.context.hidden = true;
    renderSelected();
  }
  function renderSummary(job) {
    ui.summary.hidden = false; ui.summary.replaceChildren();
    const title = node('div', 'summary-title');
    title.append(node('strong', '', `Задача ${String(job.job_id).slice(0, 8)}`), node('span', `status-label ${['done', 'error'].includes(job.status) ? job.status : ''}`, statusNames[job.status] || job.status));
    ui.summary.append(title);
    const processed = numeric(job.processed_positions) || 0, total = numeric(job.total_positions) || 0;
    const elapsed = job.stage_started_at && !terminal(job) ? `на этапе ${Math.max(0, Math.round((Date.now() - Date.parse(job.stage_started_at)) / 1000))} с` : '';
    const message = [job.message, job.current_file, `${processed} / ${total || '—'} позиций`, elapsed].filter(Boolean).join(' · ');
    ui.summary.append(node('p', 'summary-message', message));
    const entries = Object.entries(job.timings || {});
    if (entries.length) { const timings = node('div', 'timings'); for (const [key, value] of entries) timings.append(node('span', '', `${key}: ${metric(value)} с`)); ui.summary.append(timings); }
  }
  function renderErrors(errors, jobErrors = []) {
    const combined = [...list(errors), ...list(jobErrors)];
    const seen = new Set(); const unique = combined.map(text).filter((entry) => { if (!entry || seen.has(entry)) return false; seen.add(entry); return true; });
    ui.errors.replaceChildren(); ui.errors.hidden = !unique.length;
    if (!unique.length) return;
    ui.errors.append(node('h3', '', 'Обработано не всё — проверьте замечания'));
    const rows = node('ul'); unique.forEach((error) => rows.append(node('li', '', error))); ui.errors.append(rows);
  }
  function renderSelected() {
    const id = state.selectedId; if (!id) return;
    const job = state.jobs.get(id); if (!job) return;
    renderSummary(job);
    if (state.results.has(id)) {
      // Avoid destroying expanded details or keyboard focus on every poll.
      if (ui.body.dataset.renderedJob !== id) renderResults(state.results.get(id), job);
      else renderErrors(state.results.get(id).errors, job.errors);
      return;
    }
    renderErrors([], job.errors); ui.context.hidden = true; ui.count.textContent = '—';
    if (terminal(job)) { void loadResults(id); return; }
    ui.body.dataset.renderedJob = '';
    if (ui.body.dataset.loadingStatus !== job.status || ui.body.dataset.loadingJob !== id) {
      ui.body.replaceChildren(node('div', 'result-loading', job.status === 'queued' ? 'Задача в очереди. Можно добавить другие документы.' : 'Документы обрабатываются. Результаты появятся после завершения.'));
      ui.body.dataset.loadingStatus = job.status; ui.body.dataset.loadingJob = id;
    }
  }
  async function loadResults(id) {
    if (state.resultRequests.has(id)) return;
    const token = state.viewToken;
    const pending = (async () => {
      if (state.selectedId === id) { ui.body.replaceChildren(node('div', 'result-loading', 'Получаем результаты…')); ui.body.setAttribute('aria-busy', 'true'); }
      try {
        const data = await request(`/jobs/${encodeURIComponent(id)}/results`); state.results.set(id, data);
        if (state.selectedId === id && token === state.viewToken) renderResults(data, state.jobs.get(id));
      } catch (error) {
        if (state.selectedId === id && token === state.viewToken) {
          const failure = node('div', 'result-failure'); failure.append(node('p', '', `Результаты недоступны: ${error.message}`));
          const retry = node('button', 'retry-button', 'Повторить загрузку'); retry.type = 'button'; retry.addEventListener('click', () => { void loadResults(id); }); failure.append(retry); ui.body.replaceChildren(failure);
        }
      } finally { state.resultRequests.delete(id); if (state.selectedId === id) ui.body.removeAttribute('aria-busy'); }
    })();
    state.resultRequests.set(id, pending);
  }
  function renderResults(data, job) {
    ui.body.replaceChildren(); ui.body.dataset.renderedJob = String(job.job_id); ui.body.dataset.loadingStatus = ''; ui.body.removeAttribute('aria-busy');
    const items = list(data.items); ui.count.textContent = String(items.length).padStart(2, '0');
    ui.context.hidden = false;
    const hybrid = data.ranking === 'hybrid';
    const weights = data.weights || { vector: 0.8, name: 0.2 };
    const weightLabel = `${metric(weights.vector)} × vector_score + ${metric(weights.name)} × название`;
    ui.context.textContent = hybrid
      ? `Гибридный порядок: ${weightLabel}. vector_score = (cosine similarity + 1) / 2. Это не порядок математически ближайших векторов. Оценки не являются уверенностью или вероятностью соответствия.`
      : 'Векторный порядок: меньшее косинусное расстояние означает более близкий вектор. Косинусное сходство — отдельная мера, не уверенность и не вероятность соответствия.';
    if (data.search_kind === 'exact') ui.context.append(node('span', '', ' Поиск: точный (exact), не приближённый.'));
    if (data.latest_active === false || data.latest_active === 'false') ui.context.append(node('span', '', ' Включены исторические и недействующие версии.'));
    else if (data.latest_active === true || data.latest_active === 'true') ui.context.append(node('span', '', ' Фильтр: последние действующие версии.'));
    renderErrors(data.errors, job.errors);
    if (!items.length) ui.body.append(node('div', 'no-candidates', job.status === 'error' ? 'Задача завершилась ошибкой. Проверьте замечания выше.' : 'Извлечённые позиции отсутствуют. Проверьте документ и замечания выше.'));
    items.forEach((item, index) => ui.body.append(productCard(item, index, hybrid)));
  }
  function productCard(item, index, hybrid) {
    const product = item.product || item.position || item;
    const card = node('article', 'product-card');
    const header = node('div', 'product-heading'), titleBox = node('div');
    const title = node('h3', '', product.name || 'Позиция без названия'); title.id = `product-${index}`; card.setAttribute('aria-labelledby', title.id);
    titleBox.append(title);
    const meta = node('div', 'product-meta');
    if (product.brand) meta.append(node('span', '', `Бренд: ${text(product.brand)}`));
    if (product.model) meta.append(node('span', '', `Модель: ${text(product.model)}`));
    if (product.quantity !== null && product.quantity !== undefined) meta.append(node('span', '', `${text(product.quantity)} ${text(product.unit)}`.trim()));
    if (meta.childNodes.length) titleBox.append(meta);
    header.append(node('span', 'product-number', String(index + 1).padStart(2, '0')), titleBox); card.append(header);
    if (list(product.attributes).length) {
      const attrs = node('div', 'attribute-list');
      for (const attribute of product.attributes) attrs.append(node('span', 'attribute', `${text(attribute.name)}: ${text(attribute.value)} ${text(attribute.unit)}`.trim()));
      card.append(attrs);
    }
    if (product.uncertain === true || (Array.isArray(product.uncertain) && product.uncertain.length) || (typeof product.uncertain === 'string' && product.uncertain)) card.append(node('div', 'uncertain-note', `Неоднозначное извлечение: ${product.uncertain === true ? 'проверьте позицию по источнику' : text(product.uncertain)}`));
    const source = node('details', 'source-details');
    source.append(node('summary', '', `Источник и извлечение${product.source ? ` · ${text(product.source)}` : ''}`));
    source.append(node('blockquote', 'source-quote', product.raw_text || 'Исходная цитата не предоставлена.'));
    if (product.evidence_type) source.append(node('p', 'extraction-note', `Тип свидетельства: ${text(product.evidence_type)}`));
    if (product.corrections && text(product.corrections)) source.append(node('p', 'extraction-note', `Исправления при извлечении: ${text(product.corrections)}`));
    card.append(source);
    const distinct = [], codes = new Set();
    for (const candidate of list(item.candidates || product.candidates)) {
      const code = text(candidate.code).trim(); if (!code || codes.has(code)) continue;
      codes.add(code); distinct.push(candidate); if (distinct.length === 5) break;
    }
    if (!distinct.length) card.append(node('div', 'no-candidates', 'Кандидаты для этой позиции не найдены.'));
    else { const candidates = node('div', 'candidate-list'); distinct.forEach((candidate, rank) => candidates.append(candidateCard(candidate, rank, hybrid))); card.append(candidates); }
    return card;
  }
  function candidateCard(candidate, rank, hybrid) {
    const row = node('section', 'candidate');
    const top = node('div', 'candidate-top'), label = node('div');
    label.append(node('span', 'candidate-code', candidate.code), node('h4', 'candidate-name', candidate.name || 'Без названия'));
    const score = node('div', 'candidate-score', metric(hybrid ? candidate.combined_score : candidate.cosine_distance));
    score.append(node('small', '', hybrid ? 'гибридная оценка' : 'косинусное расстояние'));
    top.append(node('span', 'candidate-rank', String(rank + 1).padStart(2, '0')), label, score); row.append(top);
    const active = candidate.status === 'ACTIVE';
    const version = node('div', 'candidate-version');
    version.append(node('span', `status-badge${active ? '' : ' historical'}`, candidate.status || 'СТАТУС НЕИЗВЕСТЕН'), node('span', '', `Версия: ${text(candidate.version) || 'не указана'}`));
    row.append(version);
    if (!active) row.append(node('p', 'historical-warning', 'Историческая / недействующая запись либо неизвестный статус. Требуется проверка актуальности.'));
    const details = node('details', 'candidate-details');
    details.append(node('summary', '', `Характеристики и метрики · ${list(candidate.characteristics).length}`));
    const metrics = node('div', 'score-grid');
    for (const [name, value] of [['Косинусное расстояние ↓', candidate.cosine_distance], ['Косинусное сходство ↑', candidate.cosine_similarity], ['Совпадение названия ↑', candidate.name_score], ['Гибридная оценка ↑', candidate.combined_score]]) {
      const entry = node('div'); entry.append(node('span', '', name), node('strong', '', metric(value))); metrics.append(entry);
    }
    details.append(metrics, node('p', 'metric-note', 'Расстояние и сходство — разные метрики. Ни одна оценка не является уверенностью. ACTIVE — статус версии, а не проверка закупки.'));
    const characteristics = list(candidate.characteristics);
    if (characteristics.length) {
      const table = node('table', 'characteristics'); table.append(node('caption', '', 'Характеристики записи каталога'));
      const head = node('thead'), tr = node('tr');
      for (const title of ['Характеристика', 'Правило выбора', 'Допустимые значения']) { const th = node('th', '', title); th.scope = 'col'; tr.append(th); }
      head.append(tr); table.append(head); const body = node('tbody');
      for (const characteristic of characteristics) {
        const row = node('tr'); const name = node('td', '', characteristic.name || 'Без названия');
        const required = characteristic.required;
        name.append(node('span', 'characteristic-required', required === true || required === 'true' ? 'Обязательная' : required === false || required === 'false' ? 'Необязательная' : 'Обязательность не указана'));
        const choiceType = text(characteristic.choice_type);
        const choices = { single: 'Одно значение', multiple: 'Несколько значений', range: 'Диапазон', SINGLE: 'Одно значение', MULTIPLE: 'Несколько значений' };
        const choice = node('td', '', choices[choiceType] || choiceType || 'Не указано');
        const values = node('td'); const allowed = list(characteristic.values);
        if (allowed.length) { const ul = node('ul', 'allowed-values'); allowed.forEach((value) => ul.append(node('li', '', value))); values.append(ul); }
        else values.textContent = 'Не указаны';
        row.append(name, choice, values); body.append(row);
      }
      table.append(body); details.append(table);
      details.append(node('p', 'metric-note', 'Допустимые значения — варианты по правилам каталога, а не одновременные свойства исходного товара.'));
    } else details.append(node('p', 'metric-note', 'Характеристики для этой версии не предоставлены.'));
    row.append(details); return row;
  }
  async function health() {
    try {
      const data = await request('/health');
      const status = String(data.status || 'unknown');
      const online = ['ok', 'healthy', 'ready', 'up'].includes(status.toLowerCase());
      $('health-status').className = `service-state ${online ? 'online' : 'offline'}`;
      $('health-label').textContent = online ? 'Сервис доступен' : (data.message || 'Сервис не готов');
      $('health-status').title = text(data.metadata || status);
    } catch (error) {
      $('health-status').className = 'service-state offline'; $('health-label').textContent = 'Нет связи с сервисом'; $('health-status').title = error.message;
    }
  }
  void health(); void refreshJobs();
  window.setInterval(() => { if (!document.hidden) void poll(); }, 2500);
  window.setInterval(() => { if (!document.hidden) { void refreshJobs(); void health(); } }, 30000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { void refreshJobs(); void poll(); void health(); } });
})();
