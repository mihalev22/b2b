"""Configuration via environment; never contains catalogue credentials."""
import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent
@dataclass
class Settings:
    pg_host: str = os.getenv('PGHOST', '127.0.0.1')
    pg_port: int = int(os.getenv('PGPORT', '5432'))
    pg_database: str = os.getenv('PGDATABASE', 'ktru')
    pg_user: str = os.getenv('PGUSER', 'ai_agent')
    ollama_url: str = os.getenv('OLLAMA_URL', 'http://127.0.0.1:11434')
    embedding_model: str = os.getenv('EMBED_MODEL', 'embeddinggemma:300m')
    data_dir: Path = Path(os.getenv('MINI_DATA_DIR', str(ROOT / 'local_data')))
    vector_weight: float = float(os.getenv('VECTOR_WEIGHT', '0.8'))
    name_weight: float = float(os.getenv('NAME_WEIGHT', '0.2'))
    hybrid_pool: int = int(os.getenv('HYBRID_POOL', '50'))
    queue_size: int = int(os.getenv('QUEUE_SIZE', '8'))
    max_files: int = 10
    max_file_bytes: int = 20 * 1024 * 1024
    max_job_bytes: int = 60 * 1024 * 1024
    max_positions: int = 100
    def __post_init__(self):
        self.data_dir = self.data_dir.resolve()
        if self.data_dir.is_relative_to((ROOT / 'static').resolve()):
            raise ValueError('Private upload storage must be outside public static assets')
        if self.pg_database != 'ktru' or self.pg_user != 'ai_agent':
            raise ValueError('Only catalogue ktru / ai_agent is allowed')
        if self.pg_port == 55432:
            raise ValueError('Test PostgreSQL port is forbidden')
        if not (0 <= self.vector_weight <= 1 and 0 <= self.name_weight <= 1 and abs(self.vector_weight + self.name_weight - 1) < 1e-9):
            raise ValueError('Ranking weights must be nonnegative and sum to 1')
        if not (5 <= self.hybrid_pool <= 500 and 1 <= self.queue_size <= 100):
            raise ValueError('Unsafe pool or queue size')
