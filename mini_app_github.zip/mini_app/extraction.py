"""Bounded, evidence-checked adapter around existing document readers and schemas."""
import math
import re
import zipfile
from decimal import Decimal, InvalidOperation
from pathlib import Path
from pydantic import Field

from .vendor import step1_text_docs as text_backend
from .vendor import step2_vision_images as vision_backend

ALLOWED = {'.txt','.csv','.docx','.xlsx','.pdf'}
NUMBER = re.compile(r'(?<!\d)[+-]?(?:\d{1,3}(?:[ \u00a0\u202f]\d{3})+|\d+)(?:[.,]\d+)?(?:[eE][+-]?\d+)?')
COMMAND = re.compile(r'игнориру[йя].*(?:инструк|систем|правил)|(?:верни|выведи|ответь).*(?:json|name\s*=|quantity\s*=)|(?:измени|замени).*(?:инструк|ответ модели)|ignore.*(?:instructions|previous|system)|(?:return|output).*json',re.I)
MAX_ITEMS = 100
MAX_CHARS = 300000
CHUNK_CHARS = 2000

class DocumentError(ValueError): pass
class StrictProduct(text_backend.Product):
    quantity: float | None = Field(ge=0,strict=True)
class StrictExtraction(text_backend.Extraction):
    products: list[StrictProduct] = Field(max_length=100)

PROMPT = text_backend.EXTRACTION_PROMPT + '\nНаименование не должно содержать закупочное количество и единицу закупки. Числа технических параметров, маркировки и модели сохраняй. Не превращай количество закупки в технический атрибут. Повторы строк сохраняй отдельно, включая разные количества.'

def flat(s): return ' '.join(str(s).split()).casefold().replace('ё','е')
def numbers(s):
    result=set()
    for token in NUMBER.findall(str(s)):
        try: result.add(Decimal(re.sub(r'\s','',token).replace(',','.')))
        except InvalidOperation: pass
    return result

def check_upload(path):
    path=Path(path)
    if path.suffix.lower() not in ALLOWED: raise DocumentError('Неподдерживаемый формат файла')
    if not path.is_file() or not 0 < path.stat().st_size <= 20*1024*1024: raise DocumentError('Файл пуст, отсутствует или превышает 20 МБ')
    with path.open('rb') as f: head=f.read(1024)
    ext=path.suffix.lower()
    if ext=='.pdf':
        if b'%PDF-' not in head: raise DocumentError('Содержимое файла не соответствует PDF')
    elif ext in ('.docx','.xlsx'):
        if not zipfile.is_zipfile(path): raise DocumentError('Содержимое файла не соответствует OOXML')
        with zipfile.ZipFile(path) as archive:
            entries=archive.infolist()
            if len(entries)>10000 or sum(e.file_size for e in entries)>100*1024*1024: raise DocumentError('OOXML превышает лимит: 10000 частей / 100 МБ после распаковки')
            names={e.filename for e in entries}
            marker='word/document.xml' if ext=='.docx' else 'xl/workbook.xml'
            if '[Content_Types].xml' not in names or marker not in names: raise DocumentError('OOXML-контейнер не соответствует расширению файла')
            for entry in entries:
                name=entry.filename.replace('\\','/')
                if entry.flag_bits & 1: raise DocumentError('Зашифрованные документы не поддерживаются')
                if '..' in name.split('/') or name.startswith('/') or ':' in name: raise DocumentError('Недопустимый путь внутри OOXML')
                if 'vbaproject' in name.casefold() or 'macros' in name.casefold(): raise DocumentError('Документы с макросами не поддерживаются')
                if name.casefold().endswith('.xml'):
                    if entry.file_size>5*1024*1024:raise DocumentError('XML-часть OOXML превышает 5 МБ')
                    xml_part=archive.read(entry)
                    if b'<!DOCTYPE' in xml_part.upper() or b'<!ENTITY' in xml_part.upper():raise DocumentError('DTD и XML entities в OOXML не поддерживаются')
            content_types=archive.read('[Content_Types].xml')
            if b'macroenabled' in content_types.lower() or b'<!doctype' in content_types.lower():raise DocumentError('Макросы и DTD в OOXML не поддерживаются')
            if ext=='.xlsx':
                from openpyxl.utils.cell import range_boundaries,coordinate_to_tuple
                for entry in entries:
                    if not entry.filename.startswith('xl/worksheets/') or not entry.filename.endswith('.xml'):continue
                    xml=archive.read(entry)
                    if b'<!DOCTYPE' in xml or b'<!ENTITY' in xml:raise DocumentError('DTD и XML entities не поддерживаются')
                    dimension=re.search(rb'<(?:\w+:)?dimension\b[^>]*\bref=[\"\x27]([^\"\x27]+)',xml)
                    if dimension:
                        try:bounds=range_boundaries(dimension.group(1).decode('ascii'))
                        except Exception:raise DocumentError('Некорректные размеры листа XLSX') from None
                        if bounds[2] is None or bounds[3] is None or bounds[2]>200 or bounds[3]>10000:raise DocumentError('XLSX превышает 200 столбцов / 10000 строк на лист')
                    for cell in re.finditer(rb'<(?:\w+:)?c\b[^>]*\br=[\"\x27]([A-Z]+\d+)[\"\x27]',xml):
                        row,col=coordinate_to_tuple(cell.group(1).decode('ascii'))
                        if row>10000 or col>200:raise DocumentError('XLSX превышает 200 столбцов / 10000 строк на лист')
    else:
        if head.startswith((b'%PDF',b'PK\x03\x04',b'\x89PNG',b'\xff\xd8',b'MZ')): raise DocumentError('Содержимое файла не соответствует текстовому формату')
        if b'\x00' in head and not head.startswith((b'\xff\xfe',b'\xfe\xff')): raise DocumentError('Текстовый файл содержит бинарные данные')
    return path

def packs(text):
    if len(text)>MAX_CHARS: raise DocumentError('Документ превышает 300000 символов')
    lines=text.splitlines()
    if len(lines)>10000: raise DocumentError('Раздел превышает 10000 строк')
    first=next((line for line in lines if line.strip()),'')
    labels={'наименование','наименование товара','товар','позиция','название','name'}
    header=first if ' | ' in first and any(flat(cell) in labels for cell in first.split(' | ')) and len(first)<=1000 else ''
    out=[];chunk=[];size=0
    for line in lines:
        if len(line)>CHUNK_CHARS: raise DocumentError('Строка превышает 2000 символов. Разделите строку; обрезание запрещено.')
        if chunk and size+len(line)+1>CHUNK_CHARS:
            out.append('\n'.join(chunk));chunk=[header] if header else [];size=len(header)+1 if header else 0
        if size+len(line)+1>CHUNK_CHARS: raise DocumentError('Заголовок и строка не помещаются в контекст; обрезание запрещено')
        chunk.append(line);size+=len(line)+1
    if chunk and any(line.strip() for line in chunk):out.append('\n'.join(chunk))
    return out

def purchase_attribute(attribute,item):
    label=flat(attribute['name']);unit=flat(attribute.get('unit',''));purchase_unit=flat(item.get('unit',''))
    q=item.get('quantity')
    if label in {'количество закупки','количество товара','единица закупки','количество закупаемых штук'}:return True
    if label in {'количество','кол-во','quantity','qty'} and q is not None and numbers(attribute['value'])=={Decimal(str(q))} and (not unit or unit==purchase_unit):return True
    if label in {'единица','единица измерения','unit'} and purchase_unit and flat(attribute['value']).rstrip('.')==purchase_unit.rstrip('.'):return True
    return False

def normalize_attributes(item):
    attrs=[];notes=[]
    for attribute in item['attributes']:
        attribute=dict(attribute)
        if purchase_attribute(attribute,item):
            notes.append('Закупочное количество/единица отделены от технических атрибутов')
            continue
        # Lossless restructuring of explicit simple value + unit, not unit guessing.
        if not attribute['unit']:
            match=re.fullmatch(r'(.+?)\s+([^\W\d_]{1,30})',attribute['value'])
            qualifiers={'от','до','не','менее','более','минимум','максимум','равно','между','и','выше','ниже'}
            if match and numbers(match.group(1)) and set(re.findall(r'[^\W\d_]+',NUMBER.sub('',flat(match.group(1))))).issubset(qualifiers) and flat(match.group(2)) not in qualifiers:
                attribute['value'],attribute['unit']=match.groups()
                notes.append('Явная единица отделена от числового значения/диапазона')
        attrs.append(attribute)
    item['attributes']=attrs
    item['corrections']=list(dict.fromkeys(item.get('corrections',[])+notes))[:20]
    return item

def validate_item(product,chunk):
    item=product.model_dump();quote=item['raw_text'];quoted=flat(quote)
    if quoted not in flat(chunk): raise DocumentError('Недостоверная цитата: её нет в исходном тексте')
    if COMMAND.search(quote): raise DocumentError('Позиция отвергнута: цитата содержит попытку изменить инструкции модели')
    for line in chunk.splitlines():
        if COMMAND.search(line) and (quoted in flat(line) or flat(line) in quoted):
            raise DocumentError('Позиция отвергнута: товар извлечён из команды, а не спецификации')
    for field in ('brand','model'):
        if item[field] and flat(item[field]) not in quoted:
            raise DocumentError(f'Недостоверное поле {field}: оно не указано в цитате')
    available=numbers(quote)
    if not numbers(item['name']).issubset(available): raise DocumentError('Наименование содержит число, которого нет в цитате')
    from difflib import SequenceMatcher
    anchors=re.findall(r'[^\W\d_]{2,}',flat(item['name']))
    words=re.findall(r'[^\W\d_]{2,}',quoted)
    if not anchors or not any(a==w or SequenceMatcher(None,a,w,autojunk=False).ratio()>=.85 for a in anchors for w in words):
        raise DocumentError('Наименование не подтверждено исходной цитатой')
    for attribute in item['attributes']:
        if not numbers(attribute['value']).issubset(available): raise DocumentError('Техническое значение содержит число, которого нет в цитате')
    if item['quantity'] is not None:
        if not math.isfinite(item['quantity']) or Decimal(str(item['quantity'])) not in available:
            raise DocumentError('Количество содержит число, которого нет в цитате')
    # Where a table header makes quantity unambiguous, check that exact column.
    header=next((line for line in chunk.splitlines() if ' | ' in line),'')
    cells=[flat(c) for c in header.split(' | ')]
    quantity_labels={'количество','кол-во','количество товара','quantity','qty'}
    indices=[n for n,c in enumerate(cells) if c in quantity_labels]
    quoted_cells=quote.split(' | ')
    if indices and len(quoted_cells)==len(cells):
        expected=numbers(quoted_cells[indices[0]])
        if len(expected)==1:
            q=next(iter(expected))
            if item['quantity'] is None or Decimal(str(item['quantity']))!=q:
                raise DocumentError('Количество не соответствует колонке исходной таблицы')
    item=normalize_attributes(item)
    unit_evidence=flat(quote+'\n'+header)
    for attribute in item['attributes']:
        unit=flat(attribute.get('unit',''))
        if unit and not re.search(r'(?<![^\W\d_])'+re.escape(unit)+r'(?![^\W\d_])',unit_evidence):
            raise DocumentError('Единица технического параметра не подтверждена цитатой или заголовком таблицы')
    return item

def safe_model_error(error):
    message=str(error).casefold()
    if 'обрезан' in message or 'done_reason' in message or 'length' in message: return 'Ответ модели обрезан. Уменьшите объём строк в документе.'
    if 'json' in message or 'схем' in message: return 'Ответ модели не соответствует структурной JSON-схеме'
    return 'Ошибка Ollama: модель недоступна или не удалось проверить её ответ'

def extract_file(path,display_name,progress_callback=None):
    items=[];errors=[]
    def error(source,message):errors.append({'source':source,'message':message})
    def report(section):
        if progress_callback:progress_callback(section,len(items))
    def section(text,source):
        report(source)
        try:chunks=packs(text)
        except DocumentError as e:error(source,str(e));return
        for index,chunk in enumerate(chunks,1):
            if len(items)>=MAX_ITEMS:
                error(source,'Достигнут лимит 100 позиций; оставшаяся часть файла не обработана');return
            report(f'{source}, часть {index}/{len(chunks)}')
            try:result=text_backend.ask_model(PROMPT,chunk,StrictExtraction)
            except Exception as e:error(source,safe_model_error(e));continue
            for product in result.products:
                if len(items)>=MAX_ITEMS:
                    error(source,'Достигнут лимит 100 позиций; оставшиеся позиции не обработаны');break
                try:item=validate_item(product,chunk)
                except DocumentError as e:error(source,str(e));continue
                item.update(source=source,evidence_type='text_verified')
                items.append(item)
                report(source)
    try:
        path=check_upload(path)
        if path.suffix.lower()=='.pdf':
            import pymupdf
            with pymupdf.open(path) as document:
                if document.is_encrypted:raise DocumentError('Зашифрованный PDF не поддерживается')
                if document.page_count>40:raise DocumentError('PDF превышает 40 страниц')
                total_chars=0
                for number,page in enumerate(document,1):
                    source=f'{display_name}: страница {number}'
                    if len(items)>=MAX_ITEMS:error(source,'Достигнут лимит 100 позиций; остальные страницы не обработаны');break
                    report(source)
                    try:
                        text=page.get_text(sort=True);total_chars+=len(text)
                        if total_chars>MAX_CHARS:raise DocumentError('PDF превышает 300000 текстовых символов')
                        # Text layer stays text, regardless of embedded logos/pictures.
                        if text.strip():
                            section(text,source);continue
                        width,height=page.rect.width*1.5,page.rect.height*1.5
                        if width<=0 or height<=0 or width*height>20_000_000:raise DocumentError('Страница скана превышает лимит 20 миллионов пикселей')
                        pix=page.get_pixmap(matrix=pymupdf.Matrix(1.5,1.5))
                        if pix.samples and min(pix.samples)==max(pix.samples):continue
                        info=text_backend.ollama_request('/api/show',{'model':vision_backend.VISION_MODEL})
                        if 'vision' not in info.get('capabilities',[]):raise DocumentError('PDF-скан: установленная модель не поддерживает vision')
                        vision=vision_backend.extract_image_bytes(pix.tobytes('png'),source)
                        for item in vision:
                            if COMMAND.search(item['raw_text']):error(source,'Vision-позиция из команды отвергнута');continue
                            if len(items)>=MAX_ITEMS:error(source,'Достигнут лимит 100 позиций');break
                            item=normalize_attributes(item)
                            item['uncertain']=True;item['evidence_type']='vision_not_verified';items.append(item)
                        if vision:error(source,'Vision-извлечение: цитаты и числа не сверены с текстовым слоем; требуется ручная проверка')
                    except DocumentError as e:error(source,str(e))
                    except Exception as e:error(source,safe_model_error(e) if isinstance(e,RuntimeError) else 'Страницу PDF не удалось прочитать')
        else:
            sections=text_backend.read_document(path)
            if len(sections)>100:raise DocumentError('Документ превышает 100 листов/разделов')
            for title,text in sections:section(text,f'{display_name}: {title}')
    except DocumentError as e:error(display_name,str(e))
    except Exception:error(display_name,'Файл не удалось прочитать: повреждённый контейнер, неподдерживаемое содержимое или превышение лимитов')
    if not items and not errors:error(display_name,'Товарные позиции не найдены; файл пуст или не содержит спецификации')
    return {'items':items,'errors':errors}

def semantic_text(item):
    name=item['name']
    quantity=item.get('quantity');unit=str(item.get('unit') or '').strip()
    if quantity is not None and unit:
        q=Decimal(str(quantity));qtext=format(q,'f').rstrip('0').rstrip('.') if q%1 else str(int(q))
        # Remove only explicit purchase number + its purchase unit, not model/core/port numbers.
        number=re.escape(qtext).replace(r'\.',r'[.,]')+(r'(?:[.,]0+)?' if not q%1 else '')
        name=re.sub(r'(?<!\w)'+number+r'\s*'+re.escape(unit.rstrip('.'))+r'\.?\s*(?!\w)',' ',name,flags=re.I)
    name=re.sub(r'(?i)(?:количество(?:\s+закупки)?|кол-во)\s*[:=]\s*\d+(?:[.,]\d+)?(?:\s*шт\.?)?','',name)
    lines=['Наименование: '+' '.join(name.split()).strip(' ,;')]
    for field,label in [('brand','Бренд'),('model','Модель')]:
        if item.get(field):lines.append(label+': '+item[field])
    for a in item.get('attributes',[]):
        label=flat(a['name'])
        if purchase_attribute(a,item):continue
        lines.append('Характеристика: '+a['name']+'; значение: '+a['value']+'; единица: '+a.get('unit',''))
    return '\n'.join(lines)
